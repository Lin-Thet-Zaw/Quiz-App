package com.quizapp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.regex.*;

public class Quiz {
    private static final Logger logger = Logger.getLogger(Quiz.class.getName());

    public static void main(String[] args) {
        setupLogger();

        // Get and log the OS information
        String osInfo = OSInfoUtil.getOSInfo();

        Scanner scanner = new Scanner(System.in);

        String desc = """
            ------------------------------------------
            ICT QUIZ TEST (Multiple Choice Questions)
            ------------------------------------------
            1. FUNDAMENTALS OF INFORMATION TECHNOLOGY QUIZ
            2. COMPUTER APPLICATIONS AND OPERATIONS QUIZ
            10. EXIT
            SELECT THE QUIZ BY NUMBER.
            """;

        logger.info("From Softera Computer Education: ICT QUIZ TEST");
        logger.info("Operating System Info: " + osInfo);
        System.out.println("From Softera Computer Education: ICT QUIZ TEST");
        System.out.println();

        ArrayList<String> questionsList = new ArrayList<>();
        try {
            File fileObj = new File("input.txt");
            Scanner fileReader = new Scanner(fileObj);
            while (fileReader.hasNextLine()) {
                String line = fileReader.nextLine();
                questionsList.add(line); // Add each line to the ArrayList
            }
            fileReader.close();
        } catch (FileNotFoundException e) {
            logger.severe("An error occurred while reading the file: " + e.getMessage());
            logger.info("Operating System Info: " + osInfo);
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }

        String[] questions = questionsList.toArray(new String[0]);

        int choice;
        boolean exit = false;
        do {
            System.out.println(desc);
            try {
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline

                switch (choice) {
                    case 1:
                        runQuiz(scanner, questions, osInfo);
                        System.out.print("Do you want to try again? (y/n): ");
                        String YorN = scanner.nextLine().toLowerCase();
                        if (!YorN.equalsIgnoreCase("y")) {
                            System.out.println("Exiting the quiz. Thank you for participating!");
                            exit = true; // Set exit to true to exit the loop
                        }
                        break;
                    case 2:
                        logger.info("Quiz 2 is under development");
                        logger.info("Operating System Info: " + osInfo);
                        System.out.println("Quiz 2 is under development");
                        break;
                    case 10:
                        logger.info("Exiting the quiz. Thank you for participating!");
                        logger.info("Operating System Info: " + osInfo);
                        System.out.println("Exiting the quiz. Thank you for participating!");
                        exit = true; // Set exit to true to exit the loop
                        break;
                    default:
                        logger.warning("Invalid option. Please select a valid quiz.");
                        logger.info("Operating System Info: " + osInfo);
                        System.out.println("Invalid option. Please select a valid quiz.");
                        break;
                }
            } catch (Exception e) {
                logger.warning("Invalid input. Please enter a number.");
                logger.info("Operating System Info: " + osInfo);
                System.out.println("Invalid input. Please reenter number 1");
                scanner.nextLine(); // Clear the invalid input
            }
        } while (!exit);

        scanner.close();
    }

    private static void runQuiz(Scanner scanner, String[] questionsArray, String osInfo) {
        ArrayList<String> questions = new ArrayList<>(Arrays.asList(questionsArray));
        Collections.shuffle(questions);  // Randomize the order of questions

        Matcher matcher;
        String name;
        String emailAddress;
        Pattern emailPattern = Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
        
        
        System.out.println("Please Fill Your Info before the quiz");
        
        do {
            System.out.print("Enter your name: ");
            name = scanner.nextLine();
        } while (name.trim().isEmpty());
        
        
		do {
            System.out.print("Enter your email address to receive the results: ");
            emailAddress = scanner.nextLine();
            matcher = emailPattern.matcher(emailAddress);
            if (!matcher.matches()) {
                System.out.println("Invalid email format. Please enter a valid email address.");
            }
        } while (emailAddress.trim().isEmpty() || !matcher.matches());
        
        int score = 0;
        int questionsCount = 0;
        for (String questionData : questions) {
            String[] parts = questionData.split("\\|");
            questionsCount++;
            String question = parts[0];
            String option1 = parts[1];
            String option2 = parts[2];
            String option3 = parts.length > 4 ? parts[3] : ""; // Check if option3 exists
            String correctAnswer = parts.length > 4 ? parts[4] : parts[3]; // Correct answer position adjusts if there are 3 options

            System.out.println("Question " + questionsCount + " OF " + questions.size());
            System.out.println(question);
            System.out.println("a. " + option1);
            System.out.println("b. " + option2);
            if (!option3.isEmpty()) { // Check if option3 is not empty
                System.out.println("c. " + option3);
            }
            System.out.print("Your answer: ");
            String userAnswer = scanner.nextLine();

            String answer = "";
            switch (userAnswer.toLowerCase()) {
                case "a":
                    answer = option1;
                    break;
                case "b":
                    answer = option2;
                    break;
                case "c":
                    if (!option3.isEmpty()) {
                        answer = option3;
                    }
                    break;
                default:
                    answer = "Invalid";
                    break;
            }

            if (answer.equalsIgnoreCase(correctAnswer)) {
                logger.info("User Info : " + name + emailAddress);
                logger.info("Operating System Info: " + osInfo);
                logger.info("Question " + questionsCount + ": Correct answer given.");
                System.out.println("Correct!");
                score++;
            } else {
                logger.info("User Info : " + name + emailAddress);
                logger.info("Question " + questionsCount + ": Incorrect answer given. Correct answer is: " + correctAnswer);

                System.out.println("Incorrect. The correct answer is: " + correctAnswer);
            }
            System.out.println();
        }

        logger.info("User Info : " + name + emailAddress);
        logger.info("Operating System Info: " + osInfo);
        logger.info("Quiz finished! Your score: " + score + "/" + questions.size());
        System.out.println("Quiz finished! Your score: " + score + "/" + questions.size());
        System.out.println("Do you want to receive this ICT QUIZ TEST score by email? (Yes/No)");
        String YesorNo = scanner.nextLine().toLowerCase();;
        if (YesorNo.equalsIgnoreCase("yes")) {
            String subject = "ICT QUIZ TEST";
            String title = "ICT QUIZ TEST SOFTERA COMPUTER EDUCATION";
            String hello = "Hello - " + name;
            String content = "Quiz finished! Your score: " + score + "/" + questions.size();
            EmailSender.sendEmail(emailAddress, subject, title, hello, content);
        }else {
        	return;
        }
    }

    private static void setupLogger() {
        try {
            // Ensure the directory exists
            File logsDir = new File("logs");
            if (!logsDir.exists()) {
                logsDir.mkdir();
            }

            // Set up the file handler to log to a file in the logs directory
            FileHandler fileHandler = new FileHandler("logs/quizapp.txt", true); // Log to a .txt file
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);
            // Remove the console handler to prevent logging to the console
            logger.setUseParentHandlers(false);
        } catch (IOException e) {
            System.out.println("Failed to set up logger: " + e.getMessage());
        }
    }
}
