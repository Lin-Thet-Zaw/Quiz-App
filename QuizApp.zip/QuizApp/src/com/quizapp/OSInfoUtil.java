package com.quizapp;

public class OSInfoUtil {
    public static String getOSInfo() {
        String osName = System.getProperty("os.name");
        String osVersion = System.getProperty("os.version");
        String osArch = System.getProperty("os.arch");
        
        return String.format("OS: %s, Version: %s, Architecture: %s", osName, osVersion, osArch);
    }
}
