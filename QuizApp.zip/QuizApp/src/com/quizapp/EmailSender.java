package com.quizapp;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class EmailSender {
    private static final Logger logger = Logger.getLogger(EmailSender.class.getName());

    static {
        try {
            // Ensure the directory exists
            File logsDir = new File("logs");
            if (!logsDir.exists()) {
                logsDir.mkdir();
            }
            
            // Set up the file handler to log to a file named "email.log"
            FileHandler fileHandler = new FileHandler("logs/quizapp.txt", true);
            fileHandler.setFormatter(new SimpleFormatter());
            logger.addHandler(fileHandler);
            
            // Remove the console handler to prevent logging to the console
            logger.setUseParentHandlers(false);
        } catch (IOException e) {
            // If an exception occurs while setting up the file handler, log it to the console
            e.printStackTrace();
        }
    }
    
    public static void sendEmail(String to, String subject, String title, String hello, String content) {
        final String username = "ammoaalinthetzaw@gmail.com"; // your Gmail username
        final String password = "nwfcxkuwbpfapacf"; // your Gmail password

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress("from-email@gmail.com"));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject(subject);
            
            // Combine title and content in HTML format
            String htmlContent = "<b>" + title + "</b><br><br/>" + " <span> " + hello  + "<span/><br><br /> " + "<p>" + content + "</p>";
            message.setContent(htmlContent, "text/html");
            
            Transport.send(message);
            logger.info("Email sent successfully to: " + to);
        } catch (MessagingException e) {
            logger.severe("Failed to send email: " + e.getMessage());
            throw new RuntimeException(e);
        }
    }
}

